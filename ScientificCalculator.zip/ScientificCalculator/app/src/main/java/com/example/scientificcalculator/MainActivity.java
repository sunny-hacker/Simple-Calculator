package com.example.scientificcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.Math;

public class MainActivity extends AppCompatActivity {

    String s="";boolean prev=false,boo1=false,boo2=false,boo3=false;
    TextView input;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input = (TextView) findViewById(R.id.input);
        ((Button) findViewById(R.id.button_ac)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                input.setText("");
                s = "";
                prev = false;boo1=false;boo2=false;boo3=false;
            }
        });
        ((Button) findViewById(R.id.button_back)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (s.length() > 0) {
                    if (s.length() > 18) s = (input.getText().toString()).substring(0, 18);
                    s = s.substring(0, s.length() - 1);
                }
                input.setText(s);
            }
        });

        ((Button)findViewById(R.id.button_back)).setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                s=input.getText().toString();
                s="";
                input.setText(s);
                return false;
            }
        });

        ((Button) findViewById(R.id.button_equal)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str = "";
                s = input.getText().toString();
                if(s.length()>0){
                    if(boo1){
                        double val=Double.parseDouble(s);
                        val=(3.14/180)*val;
                        s=String.valueOf(Math.sin(val));
                        input.setText(s);
                        boo1=false;
                    }
                    else if(boo2){
                        double val=Double.parseDouble(s);
                        val=(3.14/180)*val;
                        s=String.valueOf(Math.cos(val));
                        input.setText(s);
                        boo2=false;
                    }
                    else if(boo3){
                        double val=Double.parseDouble(s);
                        val=(3.14/180)*val;
                        s=String.valueOf(Math.tan(val));
                        input.setText(s);
                        boo3=false;
                    }
                    else {
                        char ch = s.charAt(s.length() - 1);
                        if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '^') {
                            for (int i = 0; i < s.length() - 1; i++) str += s.charAt(i);
                            s = str;
                        }
                        display('$');
                    }
                    prev=true;
            }
            }
        });
        ((Button) findViewById(R.id.button_dot)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s = input.getText().toString();
                if (prev) {
                    s = ".";
                    prev = false;
                } else if (s.indexOf('.') == -1 && s.length() < 18) s += '.';
                else {
                    int pos = -1;
                    if (s.indexOf('+') != -1) pos = s.indexOf('+');
                    if (s.indexOf('-') != -1) pos = s.indexOf('-');
                    if (s.indexOf('/') != -1) pos = s.indexOf('/');
                    if (s.indexOf('*') != -1) pos = s.indexOf('*');
                    if (s.indexOf('^') != -1) pos = s.indexOf('^');
                    if (pos == -1 || s.indexOf('.') > pos)
                        Toast.makeText(getApplicationContext(), "You Can't enter another dot", Toast.LENGTH_LONG).show();
                    else {
                        int cnt = 0;
                        for (int i = 0; i < s.length(); i++) {
                            if (s.charAt(i) == '.') cnt++;
                        }
                        if (cnt < 2 && s.length() < 18) {
                            s += '.';
                        } else {
                            Toast.makeText(getApplicationContext(), "You Can't enter another dot", Toast.LENGTH_LONG).show();
                        }
                    }
                }
                input.setText(s);
            }
        });
        ((Button) findViewById(R.id.button_zero)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (s.length() < 18) s = (input.getText().toString() + '0');
                if (prev) {
                    s = "0";
                    prev = false;
                }
                input.setText(s);
            }
        });
        ((Button) findViewById(R.id.button_one)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (s.length() < 18) s = (input.getText().toString() + '1');
                if (prev) {
                    s = "1";
                    prev = false;
                }
                input.setText(s);
            }
        });
        ((Button) findViewById(R.id.button_two)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (s.length() < 18) s = (input.getText().toString() + '2');
                if (prev) {
                    s = "2";
                    prev = false;
                }
                input.setText(s);
            }
        });
        ((Button) findViewById(R.id.button_three)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (s.length() < 18) s = (input.getText().toString() + '3');
                if (prev) {
                    s = "3";
                    prev = false;
                }
                input.setText(s);
            }
        });
        ((Button) findViewById(R.id.button_four)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (s.length() < 18) s = (input.getText().toString() + '4');
                if (prev) {
                    s = "4";
                    prev = false;
                }
                input.setText(s);
            }
        });
        ((Button) findViewById(R.id.button_five)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (s.length() < 18) s = (input.getText().toString() + '5');
                if (prev) {
                    s = "5";
                    prev = false;
                }
                input.setText(s);
            }
        });
        ((Button) findViewById(R.id.button_six)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (s.length() < 18) s = (input.getText().toString() + '6');
                if (prev) {
                    s = "6";
                    prev = false;
                }
                input.setText(s);
            }
        });
        ((Button) findViewById(R.id.button_seven)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (s.length() < 18) s = (input.getText().toString() + '7');
                if (prev) {
                    s = "7";
                    prev = false;
                }
                input.setText(s);
            }
        });
        ((Button) findViewById(R.id.button_eight)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (s.length() < 18) s = (input.getText().toString() + '8');
                if (prev) {
                    s = "8";
                    prev = false;
                }
                input.setText(s);
            }
        });
        ((Button) findViewById(R.id.button_nine)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (s.length() < 18) s = (input.getText().toString() + '9');
                if (prev) {
                    s = "9";
                    prev = false;
                }
                input.setText(s);
            }
        });
        ((Button) findViewById(R.id.button_plus)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s = input.getText().toString();
                if (prev) prev = false;
                if (s.equals(""))
                    Toast.makeText(getApplicationContext(), "Enter the operands first...", Toast.LENGTH_SHORT).show();
                else {
                    char c = s.charAt(s.length() - 1);
                    if (c == '-' || c == '/' || c == '*' || c == '+' || c == '^') {
                        String str = "";
                        for (int i = 0; i < s.length() - 1; i++) str += s.charAt(i);
                        str.concat(String.valueOf(c));
                        s = str;
                    }
                    display('+');
                }
            }
        });
        ((Button) findViewById(R.id.button_minus)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s = input.getText().toString();
                if (prev) prev = false;
                if (s.equals(""))
                    Toast.makeText(getApplicationContext(), "Enter the operands first...", Toast.LENGTH_SHORT).show();
                else {
                    char c = s.charAt(s.length() - 1);
                    if (c == '+' || c == '/' || c == '*' || c == '-' || c == '^') {
                        String str = "";
                        for (int i = 0; i < s.length() - 1; i++) str += s.charAt(i);
                        str.concat(String.valueOf(c));
                        s = str;
                    }
                    display('-');
                }
            }
        });
        ((Button) findViewById(R.id.button_divide)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s = input.getText().toString();
                if (prev) prev = false;
                if (s.equals(""))
                    Toast.makeText(getApplicationContext(), "Enter the operands first...", Toast.LENGTH_SHORT).show();
                else {
                    char c = s.charAt(s.length() - 1);
                    if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^') {
                        String str = "";
                        for (int i = 0; i < s.length() - 1; i++) str += s.charAt(i);
                        str.concat(String.valueOf(c));
                        s = str;
                    }
                    display('/');
                }
            }
        });
        ((Button) findViewById(R.id.button_multiply)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s = input.getText().toString();
                if (prev) prev = false;
                if (s.equals(""))
                    Toast.makeText(getApplicationContext(), "Enter the operands first...", Toast.LENGTH_SHORT).show();
                else {
                    char c = s.charAt(s.length() - 1);
                    if (c == '+' || c == '/' || c == '-' || c == '*' || c == '^') {
                        String str = "";
                        for (int i = 0; i < s.length() - 1; i++) str += s.charAt(i);
                        str.concat(String.valueOf(c));
                        s = str;
                    }
                    display('*');
                }
            }
        });
        ((Button) findViewById(R.id.button_pow)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s = input.getText().toString();
                if (prev) prev = false;
                if (s.equals(""))
                    Toast.makeText(getApplicationContext(), "Enter the operands first...", Toast.LENGTH_SHORT).show();
                else {
                    char c = s.charAt(s.length() - 1);
                    if (c == '+' || c == '-' || c == '/' || c == '*') {
                        String str = "";
                        for (int i = 0; i < s.length() - 1; i++) str += s.charAt(i);
                        str.concat(String.valueOf(c));
                        s = str;
                    }
                    display('^');
                }
            }
        });
        ((Button) findViewById(R.id.button_percent)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s = input.getText().toString();
                if (s.equals(""))
                    Toast.makeText(getApplicationContext(), "Enter the operands first...", Toast.LENGTH_SHORT).show();
                else {
                    double val=Double.parseDouble(s);
                    val/=100;
                    s=String.valueOf(val);
                    input.setText(s);
                }
            }
        });
        ((Button)findViewById(R.id.button_sin)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s=input.getText().toString();
                if(!s.equals(""))
                    Toast.makeText(getApplicationContext(),"Clear the value in degree then, enter click sin button then enter the value, then click equal button...",Toast.LENGTH_LONG).show();
                else{
                    boo1=true;boo2=false;boo3=false;
                }
            }
        });
        ((Button)findViewById(R.id.button_cos)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s=input.getText().toString();
                if(!s.equals(""))
                    Toast.makeText(getApplicationContext(),"Clear the value in degree then, enter click cos button then enter the value, then click equal button...",Toast.LENGTH_LONG).show();
                else{
                    boo2=true;boo1=false;boo3=false;
                }
            }
        });
        ((Button)findViewById(R.id.button_tan)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s=input.getText().toString();
                if(!s.equals(""))
                    Toast.makeText(getApplicationContext(),"Clear the value in degree then, enter click tan button then enter the value, then click equal button...",Toast.LENGTH_LONG).show();
                else{
                    boo3=true;boo1=false;boo2=false;
                }
            }
        });
    }
    public void display(char ch){
        String s1="",s2="";boolean boo=true;char ct='+';
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            if(i==0){
                s1 += c;continue;}
            switch (c) {
                case '+':
                case '-':
                case '*':
                case '/':
                case '^':
                    boo = false;
                    ct = c;
                    continue;
            }
            if(boo) s1 += c;
            else
                s2+=c;
        }
        if(!boo){
            double val1=Double.parseDouble(s1),val = 0.0;
            double val2=Double.parseDouble(s2);
            switch (ct) {
                case '+':
                    val = val1 + val2;
                    s = String.format("%.1f", val);
                    break;
                case '-':
                    val = val1 - val2;
                    s = String.format("%.1f", val);
                    break;
                case '*':
                    val = val1 * val2;
                    s = String.format("%.1f", val);
                    break;
                case '^':
                    s = String.format("%.6f",find(val1,val2));
                    break;
                case '/':
                    if (val1 % val2 != 0) {
                        val = val1 / val2;
                        s = String.format("%.6f", val);
                    } else {
                        val = val1 / val2;
                        s = String.format("%.1f", val);
                    }
                    break;
            }
        }
        if(ch!='$') {
            s+=ch;
        }
        input.setText(s);
    }
    public double find(double x,double n) {
        if (n == 0.0)
            return 1.0;
        if (n == 1.0)
            return x;
        if (n < 0.0) {
            if (x == 1.0 || (x == 2.0 && n == -1.0))
                return 1.0;
            else
                return 0.0;
        }
        if (n%2==0) { //is even
            long num = (long) Math.pow(x * x, n / 2);
            if (num > Integer.MAX_VALUE) //check bounds
                return Double.MAX_VALUE;
            return (double) num;
        } else {
            long num = (long) (x * Math.pow(x * x, n / 2));
            if (num > Integer.MAX_VALUE) //check bounds
                return Double.MAX_VALUE;
            return (double) num;
        }
    }
}